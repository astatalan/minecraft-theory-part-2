#### forgot to add 

source: https://twitter.com/DoNutDecember/status/1756428206775685252

I think I forgot to explain on the archieved minecraft theory repo that my minecraft theory is the only one that can explain how end portals are originated ("endermen developed some technology" is not enough to explain). 

#### comparisons to other minecraft theories

source: https://twitter.com/DoNutDecember/status/1756407466550591763

I reason that my minecraft theories are far superior than anyone elses because they are not a reflection of what the minecraft developers think about minecraft. therefore, other people's theories are just self-fullfiling prophecies.

#### creepers, ghasts, and cats

source: https://twitter.com/DoNutDecember/status/1756451683347898453

A minecraft theory once made a connection with cats and creepers. Creepers are in desert temples. desert temples are like ancient egpytian. In ancient egpyt, cats are holy. Therefore, the creepers do not attack cats because the creepers come from desert temples which views cats as holy. But, I got jelous. However, I was able to connect ghasts with both cats and creepers all the way back when I wrote my minecraft theory in 2023.

#### opposite of a self-fullfiling prophecy

source: https://twitter.com/DoNutDecember/status/1756421171221090385

I explained that if I was in charge of developing minecraft, the coincidence that makes my minecraft theory possible about the end crystal would not been able. This is because that I didn't want ghast tear in end crystal since I thought healing connected to ghasts is too cliche.

source: https://twitter.com/DoNutDecember/status/1757210619483247101
source: https://twitter.com/DoNutDecember/status/1757211017463898548
source: https://twitter.com/DoNutDecember/status/1757211799106048455

Phantom was what I would not have voted for, but phantom (out of the 4 mobs) was the only one that fits in my minecraft theory.

source: https://twitter.com/DoNutDecember/status/1757212920801272042
source: https://twitter.com/DoNutDecember/status/1757213806768296209
source: https://twitter.com/DoNutDecember/status/1757215623111651397

Copper golem has coincidences, but allay is much better

source: https://twitter.com/DoNutDecember/status/1757215983658254529

The opposite of self-fullfiling prophecy shows that minecraft was destined to connect me to Nanjolno.

#### which came first? endermen or teleportation

source: https://twitter.com/DoNutDecember/status/1756742065021415666

I conclude after watching many minecraft theories that no one else can explain the origin of both endermen and teleportation. Either people write that endermen invented teleportation or that endermen gain ability of teleportation from nature. 

source: https://twitter.com/DoNutDecember/status/1756742541544763828

My explation being that endermen survive the fall into minecraft world using teleportation  is satisfactory. This is because natrual selection selected whatever organism that can teleport. 



#### planck scale 

source: https://twitter.com/DoNutDecember/status/1756743099382919169

because when things finally reach the surface, they fall fast. So fast that they cannot collide with matter anymore due to time dilation.

#### anime influence

source: https://twitter.com/DoNutDecember/status/1756743707372474716

It is confirmed that iron golems were influenced by an anime where mechs wake up and defend a village. Likewise, I theorize ghasts as if they came from schwarzesmarken anime.

#### my ego

source: https://twitter.com/DoNutDecember/status/1756749584204755331
source: https://twitter.com/DoNutDecember/status/1756787060340412473

I think I am really good at making minecraft theories.


#### teleportation theories

source: https://twitter.com/DoNutDecember/status/1758738768775807352

ALthough never seen, I think people would theorize it is teleportation is discrete but water is continous.


#### silverfish most likely theory

source: https://twitter.com/DoNutDecember/status/1759851017791770925

I think silverfish was made to fit the color theme of the strongholds.



#### minecraft names

source: https://twitter.com/DoNutDecember/status/1759849017142284502

Jean was probably chosen at random or a girl that notch knew. 

souce: https://twitter.com/DoNutDecember/status/1760215769231540272

lise hohenstien's last name means high stones so that is why silverfish spawn in extreme hills biome.


#### shulker

many theories are about endermen harvasting enderpearls from shulker, but my theory is that endermen made shulkers to store enderpearls.




#### pigmen

source: https://twitter.com/DoNutDecember/status/1760214859621240844
source: https://twitter.com/DoNutDecember/status/1760215331962806503

still don't know if pigmen blood being green from hydrogen sulfide has already been theorized.

















>_





#### minecraft theorizing made me connect it to love live

source: https://twitter.com/DoNutDecember/status/1756925297998418162

I made a mnemonmic in english. Neon's symbol is ne, so it works with nico nico nii

source: https://twitter.com/DoNutDecember/status/1757591010417250567
source: https://twitter.com/DoNutDecember/status/1757592204254556161
source: https://twitter.com/DoNutDecember/status/1757592949972517097
source: https://twitter.com/DoNutDecember/status/1757593140226101310
source: https://twitter.com/DoNutDecember/status/1757593299014033435
source: https://twitter.com/DoNutDecember/status/1757594209664504153
....

And many more of my tweets made on Feburary 13, 2024 connects 2nd year love live to Saturn, Neptune and Uranus.

#### minecraft theorizing made me connect it to me and you

source: https://twitter.com/DoNutDecember/status/1757203300624007663
source: https://twitter.com/DoNutDecember/status/1757563777669603727

It is not witch craft or astrology related because it works.

#### minecraft theorizing made me make a fun trivia

source: https://twitter.com/DoNutDecember/status/1758204674006503512
source: https://twitter.com/DoNutDecember/status/1758268171834839493
source: https://twitter.com/DoNutDecember/status/1758320525548327022

A answer and a question file

#### minecraft theorizing made me remind myself about highschool

source: https://twitter.com/DoNutDecember/status/1758720422588166373
source: https://twitter.com/DoNutDecember/status/1758720815745450404
source: https://twitter.com/DoNutDecember/status/1758721327131767132
source: https://twitter.com/DoNutDecember/status/1758721650579706248
source: https://twitter.com/DoNutDecember/status/1758722047151145162
source: https://twitter.com/DoNutDecember/status/1758722851043954773
source: https://twitter.com/DoNutDecember/status/1758723579544223846
source: https://twitter.com/DoNutDecember/status/1759298621575410121

Even though I was never in astronomy club. Although, in middle school, I study for all 3 years about astronomy.






