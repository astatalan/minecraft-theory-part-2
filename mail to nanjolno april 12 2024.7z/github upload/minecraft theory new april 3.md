
#### quality of life of endermen and wither

Before the formation of the overworld-nether void, endermen lived long and happy life. However, the same endermen in heaven want revenge against the endermen on overworld. They believed that the good treatment (that they recieved on earth) had hurted them. The reason is that endermen being treated good lived longer on earth, which means that they waited more to go to heaven. It is like a person eating a delicious big dinner, only to be too full to eat the birthday cake later at  night. The endermen in heaven got more and more angry thinking about the time they missed out in heaven when they were busy living on earth. So the endermen decended down from heaven in the form of withers. Luckily most of the soul sand was in the nether, so most of the withers flew up from the nether roof trying to get the overworld. After the void was created, they end up teleporting back to heaven.

#### the first beacon token was liquid neon gas

thus the endermen discover super cold technologies. liquid neon allows them to choose levitation instead the existing effects. so that is why endermen design the shulker to do levitation

#### endermen predicted polonium

poland etymology is "land of feilds". Like how bismuth is the ocean around noahs ark. the feild is what was left after the water has gone.


#### origins of 1.8 update prismarine, guardian, royal guardian, ect...

new minecraft theory theorized on april 3, 2024. prismarine comes from tauonium. which nuclides are so small they protect antimatter against redmatter. spawn is favored in the ocean because of less red matter.

Reason to store gold because of relitivistic properties.

Steve can niether create nor destroy quartz.

Tauonium is denser than nuetronium.

1.8 was quick because of a chain reaction with tauonium. tauonium help caused the endermites able to get more food because endermite .

Guardians are made of gears


23 pillars because class numbers of cyclotomic fields stop being 1 at 23. It was chosen for that reason because if there was only 1 class, then there would be bias in designing the monument since the monument builders would have a bias for imaginary prime numbers in cylotomic feild. The bias being about imaginary numbers because the floor plan is 2d and so is the imaginey plane.

37 pillars was also a candidate being that its class number is equal to or greater than the number itself (coincidentally also 69 (69 and 37 being the most chosen random numbers)). Big reason not, is that 37 is big.

Unlike muonium, Tauonium cannot create netherite. Tauonium is so dense that interactions with matter causes density to go so high that the material no longer has the cross section to absorb damage


#### more concidence of 1.8

rabbit and turtle are like tauonium and muonium which are prismarine and netherite.

Shizuku Osaka 's symbol is water. The thing that made me theorize about 1.8 was because of prismarine and prismarine is in water.

Tauonium not only overpowered the mobs, but it also gave the creative players power too!
>Many new arguments and scopes for existing commands
>Block models are now customizable via resource packs
>Signs and books can use JSON-formatted text
>Monster spawners can be quickly changed using spawn eggs
>Spectator gamemode, customized and debug mode world types


Tau symbol is trident. I have always thought it was too random to coincide with anything else other than what was in here (source: https://www.youtube.com/watch?v=3xSUwgg1L4g ) (I also am against BobbyBroccoli 's view on women's rights)


charm quark is not stable


even though there are more tauons in the nether, there is still no tauonic life.


#### tau symbol coincidence

It shows 2 opposites orbiting around and not touching. It predicted its own properties in minecraft which is that the antimatter and redmatter which are 2 opposites cannot touch because of orbit☯️ created by tauonium matter.

#### tau vs muon abundance

Muon is always more abundant than tau. It is that tauons were able to create intelligent life by protecting antimatter. Since wisdom beats strength, intelligence beats numbers, computers beat netherite. And the μ's beats the CEO of racism, oops wait its the other way around.



#### Why the guardians are aggressive

source: https://twitter.com/DoNutDecember/status/1757204144664822036

I reread my own tweet on april 4, 2024. I realize, it has tauism but not muism (musok doesn't count because etymology). Tauism is conservative. To conserve is an verb like to guard. But the that stood out to me when I first realize is that it specify hair and eye colors. The gaurdians all have the same hair and eyes color and a set for the elder gaurdian. They also attack with just the hair and eyes. Gaurdians always believe one set of colors for normal and one for elder, and all others are enemies. Guardians attack steve because Guardians are racists like the tauists in ancient asia.


#### dragon egg infertile because silverfish ate it inside out.




#### shulkers are a way for endermen to be buried




#### piglins harvast netherite to collect muons. therefore piglins do not use the loot they get. piglins were able to create their own music because they are μ's


#### while spawners turn into a different type, it spawns pigs in the meantime.








