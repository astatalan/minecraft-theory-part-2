
#### significance of the color blue

source: https://twitter.com/DoNutDecember/status/1756409889801269306
source: https://twitter.com/DoNutDecember/status/1758306456644808868

According to other minecraft theories, blue is important because it is the color of lapis lazuli, and lapis lazuli is worshiped in woodland masions and used in enchantments. However, I believe that it is because that the minecraft world was once a nuetron star and nuetron stars are blue. In a more recent tweet, I explain that evokers come from clockwork planet anime which uses the color blue. But also, the theory that blue is the color of the uv catastrophy that humans can percieve (source (vsauce video): https://www.youtube.com/shorts/bPWExuQLtUA ) (also note that infinite temperature would produce the same spectrum as uv catastrophe)

source: https://twitter.com/DoNutDecember/status/1756497781911425402

A repeat of that blue is a important color.

source: https://twitter.com/DoNutDecember/status/1756501883693174876

The theory that dragon heads were hunted is in conflict about how I explain the ender dragon in my 2023 minecraft theory. I offer the explaination that the dragon heads are fake.

source: https://twitter.com/DoNutDecember/status/1756747907103965643

ender pearls are blue because their souls release uv catastrophe since their souls are magic and not quantum.

source: https://twitter.com/DoNutDecember/status/1756749456332947963

opposite of blue is brown which is why soul sand is brown, since soul sand sucks in blue endermen souls.

source: https://twitter.com/DoNutDecember/status/1756756242540740869
source: https://twitter.com/DoNutDecember/status/1756756671584477429

I connect my 2 theories of blue together into one.




#### prismarine blocks

source: https://twitter.com/DoNutDecember/status/1756409889801269306

I theorize that prismarine follows the pattern of a nuetron star that once was the minecraft world. However, I haven't been able to theorize why until april 3rd, 2024. It is also coincidence that the light blue girl in nijigasaki's birthday is also here. more would be found on the tag "#### more coincidence of 1.8" on minecraft theory new april 3.md



#### ancient debris in minecraft, since tau particles are heavier than protons making then too dense.

source: https://twitter.com/DoNutDecember/status/1756436172903964961

This is the first time ever that I or anyone reason that ancient debris is made from muonic matter. muonic matter
turns diamond into lonsdaleite because muonic matter is very dense.

source: https://twitter.com/DoNutDecember/status/1756437908272161059

I disagree again minecraft devs, because if it was true then ancient debris being scattered because of nanjou yoshino effect (a effect that acts on redstone which I theorized in the comment section on april 14 2023) would conflict.

source: https://twitter.com/DoNutDecember/status/1756438475518210426

I used this explaination on how ancient debris could have formed. The information that the reader should conclude is that netherite decays and the muons scatter, then the nanjou yoshino effect concentrate them again forming ancient debris.

source: https://twitter.com/DoNutDecember/status/1756439891695522212

Gold has relitivistic effects, so I thought of a way which is that the electrons get replaced with muons and then the relitivistic effects on the muons give it the ability to deform diamond into lonsdaleite.


source: https://twitter.com/DoNutDecember/status/1756581616237879412

It cannot be tauonic matter because tauon are heavier than protons which would make it too dnese to have a valance shell.

source: https://twitter.com/DoNutDecember/status/1756583238904979854

Another reason why gold is that muons are attracted to heavier isotopes and gold is a very heavy isotope.

source: https://twitter.com/DoNutDecember/status/1756584193553740234
source: https://twitter.com/DoNutDecember/status/1756788041471897754

Since iron does not have relitivistiic properties like gold, the muons  would sink into the inner electron shells and have no effects on valence shell which would make the muon properties unusable.

source: https://twitter.com/DoNutDecember/status/1756593718268661873

nether has higher strange quarks that overworld (which I wrote in my minecraft theory 2023). Then, I conclude that strange quarks have enough mass to decay into muons, therefore there are more muons in the nether. THen, I explain that an attacting force also exists in muon.

source: https://twitter.com/DoNutDecember/status/1761886309520470230

smaller orbitals makes w form. w like tungsten which means dense rock. without 2 different names that would have not been possible (international relations emoji)


#### eye of ender

source: https://twitter.com/DoNutDecember/status/1756504737371799576


Repeat of how I theorized the functions of eye of ender and end portal frame. But, I conclude that I don't know why it is called eye of ender.

#### endermen life cycle

source: https://twitter.com/DoNutDecember/status/1756509016878985380

Taking into account that: endermen decompose into soul sand, endermen do not want soul sand because soul sand creates wither, and when endermen die, they bury themselves in a ender pearl to prevent themselves from turning into soul sand. 

source: https://twitter.com/DoNutDecember/status/1756781314764619879

I conclude that endermen hates water because endermen knows that water can cause decay and corrosion. And if water corrodes an endermen body (even if it is a small amount), the particles would turn into soul sand.

#### endermen eyes

source: https://twitter.com/DoNutDecember/status/1756746068358729772

Endermen eyes are influenced by the purple aerosuits in schwarzesmarken. Therefore, they are purple.

#### end portal frame

source: https://twitter.com/DoNutDecember/status/1760505621776937359

detailed diagram of the end portal frame. the spawner is very powerfull and can infinitely regenerate the endstone shell



#### importance of emeralds

source: source: https://twitter.com/DoNutDecember/status/1756757198292582403

I conclude that villagers like emeralds because of etymology. emeralds are beryllium compound. beryllium has berry (which is a sweet thing) and also has another name "glycium" named after sweetness. sweet is connected to children because children are known to be greedy for surgar.



#### minecraft purgatory

source: https://twitter.com/DoNutDecember/status/1756781615496200493
source: https://twitter.com/DoNutDecember/status/1756781314764619879

In between heaven and hell is earth. I conclude that endermen in ender pearls have afterlife in niether heaven nor hell




#### minecraft allays

source: https://twitter.com/DoNutDecember/status/1756795607404925358
source: https://twitter.com/DoNutDecember/status/1756798143029444639

I was watching about matpat's minecraft theory on allays (source: https://youtu.be/lCwKdYbPvho?t=651 ). Then I reasearched more about allays and found out that allays accept amythests. I realize amythests are made of iron, silicon, and oxygen (the 3 innermost layers of a supergiant star less than 1 day before supernova), so I was really excited that I found it out and posted it really quick. I later posted about 100 more tweets that day (feburary 11, 2024) to connect me and Nanjolno using coincidences and etymologies about astronomy.

source: https://twitter.com/DoNutDecember/status/1756836292258644367

also on the same day made a peom because allay and alloy sound similar.







#### quantum in minecraft theory

source: https://twitter.com/DoNutDecember/status/1756779631393350143

I used quantum mechanics to explain the unbreaking enchantment in my 2023 minecraft theory.


#### wither achievement 

source: https://twitter.com/DoNutDecember/status/1756846510728261652

There are 2 minecraft acheievements for spanwning the wither (Begining?) and killing the wither (Begining.). While searching for a reason why (other than begining is the opposite of end), I concluded that Begining has the same etymology as Neon, which neon is an element that if a star creates it, then it is very likely to go supernova (die).

source: https://twitter.com/DoNutDecember/status/1756851634355798109
source: https://twitter.com/DoNutDecember/status/1756851879818952940

I try to make the connection in etymology between minecraft wither achievement and stellar evolution obvious

#### beacon

source: https://twitter.com/DoNutDecember/status/1756850585913975110

I connect minecraft beacons to stellar evolution.

source: https://twitter.com/DoNutDecember/status/1756888688435319081

Obsidian (used to make beacons) has the same chemcial formula as amythest. Except obsidian comes from volcanos, and volcanos are known to contain sulfur. Which I used it to connect sulfur to stellar evolution. Also it is true that sulfur is produced along with silicon burning and that silicon turns into sulfur before turning into iron. And that sulfur follows the power of 2 like oxygen.


source: https://twitter.com/DoNutDecember/status/1756949892524646900
source: https://twitter.com/DoNutDecember/status/1758492024465244275

This time the connection between the wither achievements (Begining?) (Begining.) is that the below neon burning shell is all the ingredients for a beacon

source: https://twitter.com/DoNutDecember/status/1760381515140112560

nether star is made of neon


source: https://twitter.com/DoNutDecember/status/1760387398218010910

begining achievement is finally solved. Both achievement etymology has nothing to do with withers.

source: https://twitter.com/DoNutDecember/status/1760472512574390542
source: https://twitter.com/DoNutDecember/status/1760472940611518869

the endermen use astronomy to create and activate the beacon. silicon (glass and obsidian), oxygen (glass and obsidian), and iron (iron blocks and obsidian) were used because they were the most common

source: https://twitter.com/DoNutDecember/status/1761916938899386390
source: https://twitter.com/DoNutDecember/status/1761917072848671014
source: https://twitter.com/DoNutDecember/status/1761917413438714216

why oxygen in beacon


#### dragon egg

source: https://twitter.com/DoNutDecember/status/1759844790202511755

being useless allowed my minecraft theory to work. else, I would have a hard time connecting the white forces chorus to ender dragon

#### bed

source: https://twitter.com/DoNutDecember/status/1759847007999410471

According to my minecraft theory in 2023, Beds are mig-21 and the ender dragon is mig-23. Since, it takes 4 bed explosions to kill an enderdragon, I conclude it takes 4 mig-21 to destroy a mig-23

#### ender dragon is nanjolno

source: https://twitter.com/DoNutDecember/status/1759846634702217398
source: https://twitter.com/DoNutDecember/status/1759852964108251238
source: https://twitter.com/DoNutDecember/status/1759853352958009614

Lise (nanjolno character) and Jean (name of the ender dragon) have the same etymology as both mean "God is gracious" and so is lise because satisfaction is grace.

Lise's last name hohenstien means "high rock". When the ender dragon dies. the portal spawns on the highest part of the end island at 0,0 (source:  https://youtu.be/B4WX1Ia75cs?t=18 ). Even during earlier versions, The portal spawns where the dragon is which is most likely flying and flying is done high up. The dragon egg spawns on the highest [rock] bedrock block on it. The word high appears 3 times.

source: https://twitter.com/DoNutDecember/status/1760509347354833061

the ender dragon had to come after the wither because ghast had to first exist which ghasts came after wither.



#### silverfish etymology

source: https://twitter.com/DoNutDecember/status/1759850532238180587

I tried thinking of a way to connect silverfish to veitname war, just like how I connected beds, enderdragon, bat, and phantoms to the veitnam war in my 2023 minecraft theory.


#### chrous fruits which I would connect to the reason why it is called eyes of ender

source: https://twitter.com/DoNutDecember/status/1759862425904411052
source: https://twitter.com/DoNutDecember/status/1759863330489991461

I mention that chorus fruit only teleport where steve looks, hoping the connect it to eyes of ender. Then I decide that writting about chorus fruits being named after sound was more important. Chorus fruits are just a attempt for ender crystals to tell endermen that their real name is "tears in force" (a lyrics from white forces-fripside)

source: https://twitter.com/DoNutDecember/status/1759864689780023323

I struggled to theorize about shulkers until april 6, 2024 which you can find in my minecraft theory new.md and went back to theorizing eyes.

source: https://twitter.com/DoNutDecember/status/1759865423321858199

eyes are so important in teleportation that not only chorus fruits and eyes of ender are related, but also endermen can only detect steve if steve looks at him. 

source: https://twitter.com/DoNutDecember/status/1760209929472753786
source: https://twitter.com/DoNutDecember/status/1760210044723830873

I updated the list of what lise hohenstien became to include chorus fruits and pigs. The exact verse I cited from 1983 schwarzesmarken is "君との約束が 絆を強く結び\nいくつもの未来に響いていく結末"

source: https://twitter.com/DoNutDecember/status/1760212981864935562

Then a updated list of what lise hohenstien made


#### formation of outer end islands

source: https://twitter.com/DoNutDecember/status/1760115845210996893
source: https://twitter.com/DoNutDecember/status/1760116468023263600

Context (from my minecraft theory 2023): The end exist due to the strategic placement of bedrock which acts as a portal frame [such that the portal teleports all the end islands onto itself over and over again, which prevents the void from teleporting the end islands into the singularity]

Outer end islands already existed in minecraft ever the main island existed. When the ender dragon died in the early versions the exit portal depends on where the ender dragon died. Then in later versions of minecraft, the exit portal is always at 0,0 which is the correct placement to create a portal around the main island which teleports everything leaving the main island to the outer islands. Since in the later version, the exit portal is placed even when the ender dragon is alive, steve can skip the end fight and go to the outer islands.


#### lise hohenstien  and silverfish

source: https://twitter.com/DoNutDecember/status/1760213862266077239

end portal room designed with lise hohenstiens and silverfish being her children

source: https://twitter.com/DoNutDecember/status/1760784135688192271

ho in hohenstien. ho are more likely to get stds like silverfish is a std.







#### Unrelated news, just 1 day ago from april 3, notch returned to game developement

donno if true don't care. probably on the day after april fools to make it mean serious.




#### endermen wither fight

source: https://twitter.com/DoNutDecember/status/1760368512231465112

instead of the endermen immediately fighting the wither, I thought about what if the endermen were also discovering astronomy.

source: https://twitter.com/DoNutDecember/status/1760368931401843000

after the withers killed all the endermen in the nether, they float up trying to go to the overworld. The overworld endermen came back to the nether through nether portal. THe endermen looked up and saw lights above the nether as if they are supernovas. They conclude that god is creating a new heaven between the earth and nether.

source: https://twitter.com/DoNutDecember/status/1760375883506782549

an achievement was made for discovering the lights above the nether and it was the "begining?" achievement

source: https://twitter.com/DoNutDecember/status/1760376323136974956

the minecraft crust was renamed to overworld since the endermen believe that there is now a heaven between the crust and nether.

source: https://twitter.com/DoNutDecember/status/1760376594856600003
source: https://twitter.com/DoNutDecember/status/1760378351368163773
source: https://twitter.com/DoNutDecember/status/1760378719691026631

in order for endermen in my minecraft theory 2023 to joke about "nether star", they have to know about blackholes

source: https://twitter.com/DoNutDecember/status/1760377709522260225

2 conflicting etymologies of neon, both of which are important

source: https://twitter.com/DoNutDecember/status/1760386832993591689

nether stars were first discovered as if they dropped from supernovas.




#### real reason why the endermen hated the ghast

source: https://twitter.com/DoNutDecember/status/1760380023171637695
source: https://twitter.com/DoNutDecember/status/1760380353410154982
source: https://twitter.com/DoNutDecember/status/1760380614509805884

endermen observed that defeating the wither caused the nether to lock the heaven away from them with a grey sky (bedrock). The endermen thought that fighting the ghast in the overworld would cause the same to the overworld sky.

source: https://twitter.com/DoNutDecember/status/1760453916997615904

like how a child with a pet cataillar with a maggot infestation would think the white dots are cool and not a maggot infestation, the endermen think the lights (also white dots) in the nether is heaven and not their enemies.


#### alternate reason for no wither in end

source: https://twitter.com/DoNutDecember/status/1760381515140112560

if this was true (to patch that withers can go through end portal), more holes would appear.


#### how the endermen prove the existance of God

source: https://twitter.com/DoNutDecember/status/1760467421700251876
source: https://twitter.com/DoNutDecember/status/1760468231511265361
source: https://twitter.com/DoNutDecember/status/1760468564291547594

endermen observe radiactive decay for the first time from the supernova. The endermen thought that it was holy.

source: https://twitter.com/DoNutDecember/status/1760470133091238037
source: https://twitter.com/DoNutDecember/status/1760471106186588505

endermen compare the nickel series (nickel, cobalt, iron) to the trinity.

source: https://twitter.com/DoNutDecember/status/1760479460724277567
source: https://twitter.com/DoNutDecember/status/1760479722331386142
source: https://twitter.com/DoNutDecember/status/1760480125408149751

endermen connects the half-life of nickel and cobalt to the trinity.

source: https://twitter.com/DoNutDecember/status/1760480785289634239
source: https://twitter.com/DoNutDecember/status/1760481283765858701
source: https://twitter.com/DoNutDecember/status/1760481406248006029

endermen discover bismuth and connects it too. They on accidencent got that 83 is connected to bismuth.

source: https://twitter.com/DoNutDecember/status/1761109986053091455
source: https://twitter.com/DoNutDecember/status/1761480069401235900

how trinity connects to silicon, oxygen, iron too. (ingridients to activate beacon)


#### e=mc^2 in minecraft

source: https://twitter.com/DoNutDecember/status/1760505949188456759

end gateway and the portal that stabilize the end islands work the same way.




#### elements

source: https://twitter.com/DoNutDecember/status/1761914263520596085
source: https://twitter.com/DoNutDecember/status/1761914581457211416

endermen believe helium is like carbon

source: https://twitter.com/DoNutDecember/status/1761915828541313220
source: https://twitter.com/DoNutDecember/status/1761915981763391705

lead and bismuth is assciated with water.

source: https://twitter.com/DoNutDecember/status/1761916516889415752

endermen theorize white dwarfs are the angels that they will become


source: https://twitter.com/DoNutDecember/status/1761920789589238031

summary of what the endermen believe about the elements


#### berlin wall

source: https://twitter.com/DoNutDecember/status/1763377434299077086

connects berlin to fortress nothing else


#### roman historian joke

source: https://twitter.com/DoNutDecember/status/1763420700528832842

to get the joke: alpha means helium atom, but it also means a guy who is strong

source: https://twitter.com/DoNutDecember/status/1763421908278657276

forgot how to get this
























