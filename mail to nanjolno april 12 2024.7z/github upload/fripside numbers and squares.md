2020.04.01 - fripSide infinite video clips 2009-2020
01. only my railgun.mkv
02. LEVEL5 -judgelight-.mkv
03. future gazer.mkv
04. everlasting.mkv
05. Heaven is a Place on Earth.mkv
06. way to answer.mkv
07. Decade.mkv
08. sister's noise.mkv
09. eternal reality.mkv
10. black bullet.mkv
11. infinite synthesis.mkv
12. Luminize.mkv
13. Two souls -toward the truth-.mkv
14. white forces.mkv
15. 1983-schwarzesmarken-(IS3 version).mkv
16. The end of escape (fripSide×angela).mkv
17. clockwork planet.mkv
18. Red "reduction division" -crossroads version-.mkv
19. killing bites.mkv
20. divine criminal.mkv
21. Edge of the Universe.mkv
22. Love with You.mkv
23. when chance strikes.mkv
24. final phase.mkv
25. only my railgun -version2020-.mkv
Bonus. only my railgun -version2020- MV Making.mkv



1st single
0 0 flower of bravery 
sky -version 2008-


2nd single
1 1 only my railgun 
Late in autumn

only my railgun is stupid. not that I am stupid. but because railguns only store in base 1 since the off state is uncontrollable when operating. therefore only my railgun is a stupid computer.

autumn is the same word as boredom in japanese, but late in autumn, you are deep down in boredom like a computer that can only see ones and never a zero which is only my railgun

3rd single
2 4 LEVEL5 -judgelight-
memory of snow

2-ary logic is enough to do logic of anythings. Infact even though 5-ary is so much powerful, 2-ary can do everything that a 5-ary can. That is why it is LEVEL5. Logic allows LEVEL5 judgement. but why is it a judgelight instead of a judgephonon or something quantum? That is because there might exist something more powerful that turing complete. and there is no way for a judgelight to prove it because it is only as poswerful as a turing computer. So phonons might be more than turing complete. 

Turing computers have the memory of snow which is that it is high entropy like snowflake crystals, but from afar it looks completely uniform. like how all the cells in a SSD just look like normal uniform plastic.

4th single
3 9 future gazer
fortissimo-the ultimate crisis-

In the future, It would be trinary logic because trinary is the most dense storage comapred to all -arys. That is the future because now, it is too hard to do trinary. So I amd a future gazer. We already have the technology to emulate which means we can Try anytime! Why would we try though? trinary is closer to e which means it is better and do it For shining truth! And the beauty of balence trinary logic is For dreaming eyes! The market is bad. to all those who want trinary computers:
🎶 Fu woo... fu woo...
Try to be glorious believer. 🎶
And communism beats capitalism. The markets will not dictate. We will build the trinary computers Just to... go on... realize soulful heart
Such an inspring speech

The capitalists have thought that communism can never work, but when they are proven wrong it would be -the ultimate crisis-
The greek letter and culture that such capitalist logic is tied to will dissapear. It will go away and fortissimo, out of all the greek words, is now a communist terminology. fortissimo-the ultimate crisis- will discribe the collapse of the capitalist meme culture.

4 16 everlasting

Despite the fact that 4-ary logic has hundreds of millions of unique gates, it can easily be computed because they are just pairs of 2-ary logic. The ability is everlasting because it is defined in math. However, 4 pin input with 2 pin out would be overkill for hdl files.

5th single
5 25 Heaven is a Place on Earth
The end of summer

5-ary logic is so big with 10^17 unique gates that only God can compute and understand it. It is the first kind of logic that is not intuitive, which means that what we haven't reasoned with is out of reach. Infact if a 5-ary logic computer was here it would mean that Heaven is a Place on Earth. Since god is in heaven. 

You can learn this in computer organization. Since the first time that class was offered was in fall of 2023, since 3723 isn't the same, that would mean The end of summer was when I learned about it.

6th single
6 36 way to answer
last fortune

Both binary and trinary have their pros and cons. So how to resolve? make word size both bits and trits which would mean the word size is divisible by 6 since divisibility rules say that number divisible by both 2 and 3 is also by 6. Back when trinary computers exisited, having word size divisible by six is the way to answer. 

But that was back then, computers cost so much money and only fun to a few. infact it would be the last fortune that a rich family would buy. In fact trinary computer would also be the last fortune today since so much practical and easier to get a binary computer, which binary computer would not counted as a fortune. thoose early last fortune computers would have there own version of fortran.


Not only is 6 useful but the most common amount of ram is 64GiB on sumpercomputer nodes, and the limit where it would be overkill for a desktop pc is also that 64GiB is exaclty 2^36 bytes. Therefore 36 address size is the way to answer. A plus is that no waste from the unused pins and instruction handling. But since so many just choose 64 bits a 36 bit would be a last fortune considering the startup cost to make a cpu.

7 49 Decade 

Why 49? because 4 is everlasting and 9 is eternal reality, both of which are long time related like a Decade. It was on a time scale of Decade between the invinition of hack computer and macroassembler, which is needed in project 7. So it was a decade between those 2 phases. (I actaully don't know how long, but I think macroassembler might be only like 2 years old. Macroassembler is hack computer phase 2.

7th single
8 64 sister's noise
I'm believing you

My sister only knows enlish so sister's noise is base 64. Also 8bits are both kind of related to 6, 16, and 18 bits, but that would be too big of a stretch

Log4j hackers use base 64 because thoose computers are like I'm believing you when comming across the strings and then running them to get hacked


8th single
9 81 eternal reality
scorching heart

Logic can be in base 2 but that would lack sensors, instead eternal reality would be more of 9 bits like 2^9 because that can encode all 420 syllables.

But how is eternal reality? Foo・・・We can accept reality I'll link the personal wall for me and you The feeling dive into my heart So, I continue eternal reality 
You can really tell that it is a scorching heart.
 

9th single
10 100 black bullet
pico scope -SACLA-

ascii 10 is a newline. It is more like a bullet since bullets in word files cannot take the same line (spilting into columns counts as page break)

100 is really round number like a black bullet. as the 100th ascii character, I would really give the xray research facility in japan named SACLA a d grade. Not even capitalized, it is a d minus.



11 121 
infinite symthesis


so I once had a 11 character array in fortran, it was use to pick up macro assembly commands (include	def	end) especially for include because include is the longest word. include is litterally 11 because we need to take into account the enqueue temp character, null char, newline and dollar sign detection. with include you can do inifinite things because of the imports can be arbitrarly large, so it is infinite synthesis of code. now why 121? one-2-one? one-2-one is related to functions which allows you infinite synthesis (I hope this becomes a science term) because you can apply the inverse and other stuff to create anything since no information is lost in the function

10th single
12 144 
Luminize
unlimited density


project 12, 12^2 is 144 like 144 is lcm of 16 and 9. Why project 12? Luminize 💡 like make you smarter. But what else for Luminize? at 144 bits, you need to use bit shifts to tke the compressed strings into wide character with 7 bits empty each. 7 bits! that is a decade long break between each character. Just like Luminize turn energy into less dense form (which is light) Luminize does the same to data. 

This is assuming that word size is finite. Array access is quoted as constant time and not loglog. But it would be constant time if the bus size is infinite. similarily assume word size is the same as bus. that would mean we can put all characters into one word and thus unlimited density.

11th single
13 169 
Two souls -toward the truth-
冬のかけら

13^2 is 169. and 69 especially means 2 souls. when 2 souls come together like in 69, it is like yin and yang it is like me and nanjolno and that is Two souls -towards the truth-. towards the truth? now why 13 for truth. Social media takes you to the truth like how social media would take me to nanjolno. you need to be 13 to access social media.

Back when I first thought of nanjolno taking my virginity, it was closer to a 69 than anything other position. I thought about maybe something exotic like on a pile of heavy water snow or on a pool of mercury. You can call thoose 冬のかけら since they are so cold. especially mercury since it is so heat conductive.


12th single
14 196 white forces

96 creates white forces because you eject the whhite stuff outwards.


12th single
15 225 1983-schwarzesmarken-(IS3 version)

already explained down there or summerize...

In conclusion 15 (sqrt 225) is a really cool number like a music video 💚👗🔰🙋‍♀️🟢👒🪟🏳️‍🌈🪟⛪ with 1983 (one less than 📕1984) (like 15 being one less than 💻16) Blackmarks ⚫👗💼(2 black duffle bags containing humans 😟)👜 filmed in singapore ⛰️. Becuase Black is considered a cool color and singapore is a cool place to visit for the rich. Blackmarks in a foriegn language is even cooler like thoose french handbag companies that are basically scam. So german seems really cool to weird kids, add them together and get 1983 schwarzesmarken

16 256 The end of escape (fripSide×angela)

16 bits is the word size of  hack computer. So even if a hacker can inject to escape 9 bit characters buffer, 16 bits would be The end of escape

13th single
17 289 clockwork planet
Break Our Limit

17 bits Break Our Limit! not only is that 17 is one above a power of 2, but also its square is one above a number ending in 88. It may look similar to 2^n-1 but -1 to +1 is very different and +1 is not useful in computers. 

Instead computers that do not follow powers of 2 or any other divisible number is a mechanical computer. Back in clockpunk age, computers were gears and stuff thoughtfully arrranged to calculate stuff. Not wanting to be composite they would bbe prime. And 17 is what a computer on clockwork planet would have.


18 324 Red "reduction division"-crossroads version-

18 bits per byte is good because it is divisible by 6 and therefore a way to answer. but multiplying an extra 3 shows that you are reducing the influence of binary logic and going for trinary. therefore it is reduction division.

324 looks like a wavelenght. Since it is too high to see, we do music functions and go down a octave until we can perceive it. THe operation is a function because the whole visible light fits in only a single octave. And so 324 would be 648 which is red. To mix light and sound makes a intersection of a crossroads version.

14th single
19 361 killing bites
three count

At 19, it is another prime, Now you are really just killing bites since 19 would be such a bad word size. 

19 choices can easilyy fit in 3 counts of e-ary (counting system of god). e^3 is just a little to close to 20. But the most memeral coincidence of all is that hex is close to decimal, so what if you reapeat the sexy numbers 13, and 169. It still works since there is not carry. 19 base 10 is 13 base 16, and 361 base 10 is 169 base 16. three count phenomenone is so real.


15th single
20 400 divine criminal
I believe in my heart
brave new world -crossroads version- (fripSide Only)


In japan, you get adult status at 20 which means you can be a big criminal. That means divine criminal to some because japan is filled with spiritual atheists that likes to put labels on stuff. Maybe I will be a criminal when I am 20. But even if I was the real anti-christ, I would not be a divine criminal becuase religion is reletivistic. But I found a computer organization related way to do it! If I were to create my own religion and specifically make it so that I am logically proven to be the anti-christ in that religion. Anti-christ for the sake of science to be defined as someone who fakes christ. So to do that christ in the religion has to be someone else. All I need to do is to create a deep fake of a person and use her as a idol while the real person is completely against me. Now that is where the computer organization comes in. Why else is 20 and 400 so evil? because 19²+39=400=20^2 , and we all know that evil thing that happend in 1939.

How will my antichrist reilgion survive? I would need a brave new world and the people will worship my AI version of the real person. The brave new world would be -crossraods version- since in pop culture, devil exists on crossroads. Worshiping many different antichrists is a bad idea because just one need to differ would cause people to hesitate. There for we need a frip side only (assuming the other side is not flip)


21 441 Edge of the Universe



Age 21 is such a long time to wait. to University students, it is the Edge of the Universe. Literally I will go to space when I am 21. That is why so many University students stay up all night drinking underaged. 21 is such the long wait. 441 would be the 100 in a trinary computer. 2's next prime is 3. 5's next prime is 7. A black bullet in trinary computer would do a line break even if the carriage return takes them to the Edge of the Universe.



16th single
22 484 Love with You
Blue Moon

reorrient the 22^2. so now it is 4∞🫰. It reads For Infinite Finger Hearts (Love). And that is what Love with You is because You are such a good and Lovely human. 22^2 looks like two's day. That day so amny people wed because of such a coincidence. Love with You was a really good probability on 22.

 two's day only happens once in a Blue Moon, infact even 1000 years from now, it would still not be it because of 3 in 3022 and also that leap year is skipped once every 128 years (since scientist measured it more accurately this time) and 3022 would become off. 



23 529 

when chance strikes, it is 23. I see 23 I think of thoose coincidences. 69 is divisible by 23, there are just so many coincidences with 23 in numerology and math. 529 is close to 2^9, infact it is better since with 2 base 23 digits you can specify 9 bits unlike how 3 isn't enough in base 10 to get 10 bits. Now that is also when chance strikes.


17th single
24 576 final phase
promenade

sadly computer organization went from 3723 to 3724. right off of 23. But, This is a final phase that no one can replace computer organization's number. which means 4 credits instead of 3! No one can stop this phase!


why else? 5 76->3 724. 5 and  3 are alike because 1st twin prime and triple primes. then 76 the 6 split into 2 and 4. 26^2-24^2=100 going to 26 would put your trajectory on a promenade.

25 625 only my railgun -version2020-


25 like 15 and 45 are cool numbers like how I wrote about it before, so would somthing be if it was called version 2020 like only my railgun -version2020-.mkv dvsk eio deo cdn <- now why was there stupidly random characters? because it is decimal. In decimal there isn't that many divisibility rules, so the characters look quite random. But there is a 2 in base 10 which gives it binary properties. It is the 5 that is stupidly causing the trouble. Now if you were to change the 2 to a 5, you would get doubly stupid. At least it wasn't pentuply or else that would stupidly rhyme like go to (the 5th planet) jupiter to get stupider. And finally we had wrote first that railguns are stupid computers. at 5, 25, and 625 a square will end in another number that ends in it which breaks after 625.

18th single
26 676 dual existance
Reason to be here

in a dual existance we would use letters to count and numbers to spell which gives us 26 numerals. actually It is 676 being close to 666. Dual existance because 777 and 666 combine to make the devil and angel together in one number

The Reason to be here is that at 24 it was 576 and then smoothly take a promenade to 676 which is exactly 100 away


19th single
27 729 legendary future
a new day will come

Theretically, if we ever use 3-ary logic, the best possible word size and address size would be 27 because 3 trits to mention each of the 27 bits. And then word size being the same simplifies the instruction set. And then for every 27 consequtive 3 trits (loop around), there can be a instruction just for that. If it was ever implemented, it will show the supreme power of the 3-ary computer since 27 bits is the ideal. That would be a legendary future. It is the same in 16 bits in 2-ary because of the same numbers. 4 bits is too little so that wouldn't work. Likewise, All worship the hack computer. But what about 729, the 2 is hidden in there in the exponenet. Why would the number of trits need to be divisible by 2? Maybe some small operations would only need 2 states. like if it was gareenteed to be either a 0 or 1 and never a -1. a new day will come when we will understand.

20th single
28 784 Leap of faith
passage

784 has many connections which is that it has 7 and 84, however those are weak compared to the real 1984 and requires a Leap of faith. Likewise 28 is boring and just a passage to 784

>_

was browsing your old blog. End up on https://gokinjolno.jp/statics/tour2017

The ring design made me think about algebra rings or whatever math things I cannot comprehend. and 2017 remind me about clockwork planet.

cannot find list of live tours. I think it is 2015 "TOKYO 1/2650" 2016 "N32" 2017 "Birthday acuostic live" "Ring" 2018 "Memories apartment"
